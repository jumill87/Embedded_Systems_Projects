// UARTTestMain.c
// Runs on LM4F120/TM4C123
// Used to test the UART.c driver
// Daniel Valvano
// September 12, 2013

/* This example accompanies the book
   "Embedded Systems: Real Time Interfacing to Arm Cortex M Microcontrollers",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2013

 Copyright 2013 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */

// U0Rx (VCP receive) connected to PA0
// U0Tx (VCP transmit) connected to PA1

#include "PLL.h"
#include "UARTmcu1.h"
#include "tm4c123gh6pm.h"


//Initialize PortF for Lights and Buttons
void PortF_Init(void){
	unsigned long volatile delay;
	SYSCTL_RCGCGPIO_R |= 0x20;            // 2) activate port F
  SYSCTL_RCGC2_R |= 0x00000020; // (a) activate clock for port F
	delay = SYSCTL_RCGC2_R;
  GPIO_PORTF_LOCK_R = 0x4C4F434B; // unlock GPIO Port F
  GPIO_PORTF_CR_R |= 0x1F;         // allow changes to PF4,0
  GPIO_PORTF_DIR_R &= ~0x11;    // (c) PF4,0 input
	GPIO_PORTF_DIR_R |= 0x0E;    // (c) make PF3-1 out (built-in led)
	GPIO_PORTF_AFSEL_R &= ~0x1F;  //     disable alt funct on PF4,0
  GPIO_PORTF_PCTL_R &= ~0x000FFFFF; //  configure PF4-0 as GPIO
  GPIO_PORTF_AMSEL_R &= ~0x1F;          // disable analog functionality on PF4,0
  GPIO_PORTF_DEN_R |= 0x1F;             // enable digital I/O on PF4,0
  GPIO_PORTF_PUR_R |= 0x1F;     //     enable weak pull-up on PF4,0
  GPIO_PORTF_IS_R &= ~0x1F;     // (d) PF4-PF0 is edge-sensitive
  GPIO_PORTF_IBE_R &= ~0x1F;    //     PF4-PF0 is not both edges
  GPIO_PORTF_IEV_R &= ~0x1F;    //     PF4-PF0 falling edge event
  GPIO_PORTF_ICR_R = 0x1F;      // (e) clear LEDFlags 4,0
  GPIO_PORTF_IM_R |= 0x11;      // (f) arm interrupt on PF4,0
  NVIC_PRI7_R = (NVIC_PRI7_R&0xFF00FFFF)|0x00400000; // (g) priority 2
  NVIC_EN0_R = 0x40000000;      // (h) enable interrupt 30 in NVIC
}

//Global Variables
unsigned char menu;
unsigned char LEDFlag = 7, data;
unsigned char led;
unsigned char breakOut = 0;

//Function Prototypes
void setLED(char);
void Delay(void);
void DisableInterrupts(void);
void EnableInterrupts(void);
void WaitForInterrupt(void);
void SwitchC_Init(void);
//---------------------OutCRLF---------------------
// Output a CR,LF to UART to go to a new line
// Input: none
// Output: none
void OutCRLF(void){
  UART_OutChar(CR);
  UART_OutChar(LF);
}

void UART1_OutCRLF(void){
  UART1_OutChar(CR);
  UART1_OutChar(LF);
}

void PortD_Init(void){
    SYSCTL_RCGC2_R |= 0x00000008;// Actiate Port  Clock
    while ((SYSCTL_RCGC2_R&0x00000008)!=0x00000008){}
    GPIO_PORTD_PCTL_R &=~0x00000001;
    GPIO_PORTD_DIR_R &= ~0x01; // Make  input
    GPIO_PORTD_AFSEL_R &=~0x01; //Disable analog functionally
    GPIO_PORTD_DEN_R |=0x01; //Enable digital I/O on   
    GPIO_PORTD_AMSEL_R&= ~0x01;
     
    GPIO_PORTD_IS_R &=~0x11; //Make  edge sensitive
    GPIO_PORTD_IEV_R &= ~0x11;
    GPIO_PORTD_IBE_R &= 0x11; // BOTH EDGE
    GPIO_PORTD_ICR_R |=0x01; //Clear LEDFlag 
    GPIO_PORTD_IM_R |=0x01; //Arm Interrupt on 
    NVIC_PRI0_R=(NVIC_PRI0_R&0x0FFFFFFF)|0xA0000000;
    NVIC_EN0_R |= 0x00000008;	
}

void GPIOPortF_Handler() // called on touch of SW1
{ 
  if(GPIO_PORTF_RIS_R&0x10) // SW1 button
  {
		Delay();
		Delay();
		GPIO_PORTF_ICR_R = 0x10;
		LEDFlag = (LEDFlag + 1) % 8;
		switch(LEDFlag)
		{
			case 0:
				GPIO_PORTF_DATA_R = 0x02;  // LED is red;
				break;
			case 1:
				GPIO_PORTF_DATA_R = 0x0A;  // LED is yellow;
				break;
			case 2:
				GPIO_PORTF_DATA_R = 0x08;  // LED is green;
				break;
			case 3:
				GPIO_PORTF_DATA_R = 0x04;  // LED is blue;
				break;
			case 4:
				GPIO_PORTF_DATA_R = 0x0C;  // LED is light blue;
				break;
			case 5:
				GPIO_PORTF_DATA_R = 0x0E;  // LED is white;
				break;
			case 6:
				GPIO_PORTF_DATA_R = 0x06;  // LED is purple;
				break;
			case 7:
				GPIO_PORTF_DATA_R = 0x00;  // LED is dark;
				break;
			default:;
		}
	}

	if(GPIO_PORTF_RIS_R&0x01) // SW2 button
	{
			Delay();
			Delay();
			GPIO_PORTF_ICR_R = 0x01;
			UART1_OutChar(LEDFlag);
	}
}

void GPIOPortD_Handler(void){
	if(GPIO_PORTD_RIS_R&0x01)
	{
		Delay();
		Delay();
		GPIO_PORTD_ICR_R = 0x01;
		if (menu == '1')
		{
			breakOut = 1;
		}
		if (menu == '2')
		{
			LEDFlag = 7;
			UART1_OutChar(LEDFlag);
			breakOut = 1;
		}
		if (menu == '3')
		{
			//UART1_OutChar(7);
			breakOut = 1;
		}
	}
}

//debug code
int main(void){
  char string[20];  // global to assist in debugging
  char string2[35];
  DisableInterrupts();
	PortD_Init();
	PortF_Init();
  PLL_Init();
  UART_Init();              // initialize UART0
  UART1_Init();             // initialize UART1
  EnableInterrupts();
	
		while(1){
        for(unsigned long time=0; time<2000000;time++){} //debounce

    UART_OutString("Welcome to CECS 447 Project 2 – UART");
    OutCRLF();
    UART_OutString("Please choose a communication mode (type 1 or 2 or 3)");
    OutCRLF();
    UART_OutString("1. PC <-> MCU_1 only");
    OutCRLF();
    UART_OutString("2. MCU_1 <-> MCU_2 LED Control");
    OutCRLF();
    UART_OutString("3. PC <-> MCU_1 <-> MCU_2 Messenger");
    OutCRLF();
    menu = UART_InChar();
		UART_OutString("Mode: "); UART_OutChar(menu);
		OutCRLF();
		UART1_OutChar(menu); //Sends string to MCU_2
		
		while (menu == '1')
		{
			OutCRLF();
			UART_OutString("Please select a color: r(red), g(green), b(blue), p(purple), w(white), d(dark)");
			OutCRLF();
			led = UART_InChar();
			setLED(led);
			if (breakOut == 1)
			{
				breakOut = 0;
				setLED('d');
				menu = 0;
			}
		}
		
		if (menu == '2')
		{
			LEDFlag = 0;
			GPIO_PORTF_DATA_R = 0x02;
		}
		while (menu == '2')
		{
			LEDFlag = UART1_InChar();
			switch(LEDFlag)
			{
				case 0:
					GPIO_PORTF_DATA_R = 0x02;  // LED is red;
					break;
				case 1:
					GPIO_PORTF_DATA_R = 0x0A;  // LED is yellow;
					break;
				case 2:
					GPIO_PORTF_DATA_R = 0x08;  // LED is green;
					break;
				case 3:
					GPIO_PORTF_DATA_R = 0x04;  // LED is blue;
					break;
				case 4:
					GPIO_PORTF_DATA_R = 0x0C;  // LED is light blue;
					break;
				case 5:
					GPIO_PORTF_DATA_R = 0x0E;  // LED is white;
					break;
				case 6:
					GPIO_PORTF_DATA_R = 0x06;  // LED is purple;
					break;
				case 7:
					GPIO_PORTF_DATA_R = 0x00;  // LED is dark;
					break;
				default:;
			}
			if (breakOut == 1)
			{
				breakOut = 0;
				LEDFlag = 0;
				menu = 0;
			}
		}
		
		int i = 0;
		while (menu == '3')
		{
			while (i<1)
			{
				UART1_OutString(string); //Sends string to MCU_2
				UART1_OutCRLF();
				UART1_InString(string2,19); //Takes acknowledgement message from MCU_2
				i++;
			}
			OutCRLF();
			UART_OutString("Please enter a message");
			OutCRLF();
			UART_InString(string,19); //Takes in message from Console to MCU_1

			UART1_OutString(string); //Sends string to MCU_2
			UART1_OutCRLF();
			UART1_InString(string2,19); //Takes acknowledgement message from MCU_2
			UART_OutString(string2); //Outputs it on the Console
			OutCRLF();
			if (breakOut == 1)
			{
				breakOut = 0;
				menu = 0;
			}
		}
	}
}

void setLED(char led)
{
	if (led == 'r')
	{
		GPIO_PORTF_DATA_R = 0x02;  // LED is red;
		UART_OutString("Red LED is on");
		OutCRLF();

	}
	else if (led == 'g')
	{
		GPIO_PORTF_DATA_R = 0x08;  // LED is green;
		UART_OutString("Green LED is on");
		OutCRLF();
	}
	else if (led == 'b')
	{
		GPIO_PORTF_DATA_R = 0x04;  // LED is blue;
		UART_OutString("Blue LED is on");
		OutCRLF();
	}
	else if (led == 'p')
	{
		GPIO_PORTF_DATA_R = 0x06;  // LED is purple;
		UART_OutString("Purple LED is on");
		OutCRLF();
	}
	else if (led == 'w')
	{
		GPIO_PORTF_DATA_R = 0x0E;  // LED is white;
		UART_OutString("White LED is on");
		OutCRLF();
	}
	else if (led == 'd')
	{
		GPIO_PORTF_DATA_R = 0x00;  // LED is dark;
		UART_OutString("Dark LED is on");
		OutCRLF();
	}
}

void Delay(void){
	unsigned long volatile time;
  time = 727240*100/91;  // 0.1sec
  while(time)
	{
		time--;
  }
}
