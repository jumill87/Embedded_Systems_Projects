// UARTTestMain.c
// Runs on LM4F120/TM4C123
// Used to test the UART.c driver
// Daniel Valvano
// September 12, 2013

/* This example accompanies the book
   "Embedded Systems: Real Time Interfacing to Arm Cortex M Microcontrollers",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2013

 Copyright 2013 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */

// U0Rx (VCP receive) connected to PA0
// U0Tx (VCP transmit) connected to PA1

#include "PLL.h"
#include "UARTmcu2.h"
#include "tm4c123gh6pm.h"
#include "string.h"
unsigned char LEDFLag = 7,send = 0, data, menu;
unsigned char breakOut = 0;
void Send_UART(char* string){
    UART_OutString(string);
}

//button init
void PortF_Init(void){
	unsigned long volatile delay;
	SYSCTL_RCGCGPIO_R |= 0x20;            // 2) activate port F
  SYSCTL_RCGC2_R |= 0x00000020; // (a) activate clock for port F
	delay = SYSCTL_RCGC2_R;   
  GPIO_PORTF_LOCK_R = 0x4C4F434B; // unlock GPIO Port F
  GPIO_PORTF_CR_R |= 0x1F;         // allow changes to PF4,0
  GPIO_PORTF_DIR_R &= ~0x11;    // (c) PF4,0 input
	GPIO_PORTF_DIR_R |= 0x0E;    // (c) make PF3-1 out (built-in led)
	GPIO_PORTF_AFSEL_R &= ~0x1F;  //     disable alt funct on PF4,0
  GPIO_PORTF_PCTL_R &= ~0x000FFFFF; //  configure PF4-0 as GPIO
  GPIO_PORTF_AMSEL_R &= ~0x1F;          // disable analog functionality on PF4,0
  GPIO_PORTF_DEN_R |= 0x1F;             // enable digital I/O on PF4,0
  GPIO_PORTF_PUR_R |= 0x1F;     //     enable weak pull-up on PF4,0
  GPIO_PORTF_IS_R &= ~0x1F;     // (d) PF4-PF0 is edge-sensitive
  GPIO_PORTF_IBE_R &= ~0x1F;    //     PF4-PF0 is not both edges
  GPIO_PORTF_IEV_R &= ~0x1F;    //     PF4-PF0 falling edge event
  GPIO_PORTF_ICR_R = 0x1F;      // (e) clear LEDFLags 4,0
  GPIO_PORTF_IM_R |= 0x11;      // (f) arm interrupt on PF4,0
  NVIC_PRI7_R = (NVIC_PRI7_R&0xFF00FFFF)|0x00400000; // (g) priority 2
  NVIC_EN0_R = 0x40000000;      // (h) enable interrupt 30 in NVIC	
}

void PortD_Init(void){
    SYSCTL_RCGC2_R |= 0x00000008;// Actiate Port  Clock
    while ((SYSCTL_RCGC2_R&0x00000008)!=0x00000008){}
    GPIO_PORTD_PCTL_R &=~0x00000001;
    GPIO_PORTD_DIR_R &= ~0x01; // Make  input
    GPIO_PORTD_AFSEL_R &=~0x01; //Disable analog functionally
    GPIO_PORTD_DEN_R |=0x01; //Enable digital I/O on   
    GPIO_PORTD_AMSEL_R&= ~0x01;
    
			
		        
    GPIO_PORTD_IS_R &=~0x11; //Make  edge sensitive
    GPIO_PORTD_IEV_R &= ~0x11;
    GPIO_PORTD_IBE_R &= 0x11; // BOTH EDGE
    GPIO_PORTD_ICR_R |=0x01; //Clear LEDFLag 
    GPIO_PORTD_IM_R |=0x01; //Arm Interrupt on 
    NVIC_PRI0_R=(NVIC_PRI0_R&0x0FFFFFFF)|0xA0000000;
    NVIC_EN0_R |= 0x00000008;
}

// Color    LED(s) PortF
// dark     ---    0
// red      R--    0x02
// blue     --B    0x04
// green    -G-    0x08
// yellow   RG-    0x0A
// sky blue -GB    0x0C
// white    RGB    0x0E
// pink     R-B    0x06

void DisableInterrupts(void);
void EnableInterrupts(void);

// Subroutine to wait 0.1 sec for 80MHz system clock
// Inputs: None
// Outputs: None
// Notes: ...
void Delay(void){
	unsigned long volatile time;
  time = 727240*100/91;  // 0.1sec
  while(time){
		time--;
  }
}

void GPIOPortF_Handler() // called on touch of SW2
{ 
  if(GPIO_PORTF_RIS_R&0x10) // SW2 button
	{  
		Delay();
		Delay();
		GPIO_PORTF_ICR_R = 0x10;
		LEDFLag = (LEDFLag + 1) % 8;

		switch(LEDFLag)
  	{
			case 0:
				GPIO_PORTF_DATA_R = 0x02;  // LED is red;
				break;
			case 1:
				GPIO_PORTF_DATA_R = 0x0A;  // LED is yellow;
				break;
			case 2:
				GPIO_PORTF_DATA_R = 0x08;  // LED is green;
				break;
			case 3:
				GPIO_PORTF_DATA_R = 0x04;  // LED is blue;
				break;
			case 4:
				GPIO_PORTF_DATA_R = 0x0C;  // LED is light blue;
				break;
			case 5:
				GPIO_PORTF_DATA_R = 0x0E;  // LED is white;
				break;
			case 6:
				GPIO_PORTF_DATA_R = 0x06;  // LED is purple;
				break;
			case 7:
				GPIO_PORTF_DATA_R = 0x00;  // LED is dark;
				break;
			default:;
		}
	}
	
	if(GPIO_PORTF_RIS_R&0x01) // SW1 button
	{  
		Delay();
		Delay();
		GPIO_PORTF_ICR_R = 0x01;
		UART_OutChar(LEDFLag);
  }
}

void GPIOPortD_Handler(void){
	if(GPIO_PORTD_RIS_R&0x01)	{
		Delay();
		Delay();
		GPIO_PORTD_ICR_R = 0x01;
		if (menu == '2')
		{
			LEDFLag = 7;
			UART_OutChar(LEDFLag);
		}
		if (menu == '3')
		{
			//UART1_OutChar(7);
		}
		breakOut = 1;
	}
}

void UART1_OutCRLF(void){
  UART_OutChar(CR);
  UART_OutChar(LF);
}
char message[20];
char receiveMessage[35];
int i;
char j,k;
//debug code
int main(void)
{
	DisableInterrupts();
	PLL_Init();
	UART_Init();              // initialize UART
	PortD_Init();
	PortF_Init();
	EnableInterrupts();
	
	while(1)
	{
		menu = UART_InChar();
		while (menu == '1')
		{
			GPIO_PORTF_DATA_R = 0x00;
			if (breakOut == 1)
			{
				breakOut = 0;
				menu = 0;
			}
		}
		
		if (menu == '2')
		{
			LEDFLag = 7;
			GPIO_PORTF_DATA_R = 0x00;
		}
		while(menu == '2')
		{
			LEDFLag = UART_InChar();	
			switch(LEDFLag)
			{
				case 0:
					GPIO_PORTF_DATA_R = 0x02;  // LED is red;
					break;
				case 1:
					GPIO_PORTF_DATA_R = 0x0A;  // LED is yellow;
					break;
				case 2:
					GPIO_PORTF_DATA_R = 0x08;  // LED is green;
					break;
				case 3:
					GPIO_PORTF_DATA_R = 0x04;  // LED is blue;
					break;
				case 4:
					GPIO_PORTF_DATA_R = 0x0C;  // LED is light blue;
					break;
				case 5:
					GPIO_PORTF_DATA_R = 0x0E;  // LED is white;
					break;
				case 6:
					GPIO_PORTF_DATA_R = 0x06;  // LED is purple;
					break;
				case 7:
					GPIO_PORTF_DATA_R = 0x00;  // LED is dark;
					break;
				default:;
			}
			if (breakOut == 1)
			{
				breakOut = 0;
				LEDFLag = 7;
				menu = 0;
			}
		}
		
		if (menu == '3')
		{
			i = 1;
		}
		while (menu == '3')
		{
			if(i<2)
			{
				k=UART_InChar(); //Supposed to eat zero
        i +=1;
      }
			UART_InString(message,19); //Takes in message from MCU_1 Uses UART1
			j=UART_InChar(); // Supposed to eat line feed
			strcpy(receiveMessage, "Received: ");
			strcat(receiveMessage, message);
			Send_UART(receiveMessage); //Sends acknowledgement message back to MCU_1 Uses UART1 //
			UART1_OutCRLF();
			if (breakOut == 1)
			{
				breakOut = 0;
				menu = 0;
			}
		}
	}
}
